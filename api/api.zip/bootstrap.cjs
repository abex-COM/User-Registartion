import("./index.js").catch((err) => {
  console.error("Failed to start app:", err);
});
